# splat_to_mesh

A LichtFeld Studio plugin that reconstructs a polygon mesh around a 3D
Gaussian splat.

## How it works

1. Reads the active splat's positions (`means`), opacity, and scale from
   GPU tensors (`SplatData.get_means()`, `.get_opacity()`, `.get_scaling()`).
2. Filters out low-opacity gaussians (fog/noise).
3. Voxelizes the remaining splats into a density field: for every voxel,
   the `k` nearest splats each contribute `opacity * exp(-0.5*(dist/radius)^2)`,
   summed. This is a KD-tree-accelerated approximation of "how much
   Gaussian mass is near this point in space."
4. Runs marching cubes (`skimage.measure.marching_cubes`) on that field at
   a chosen iso-level to extract a watertight-ish triangle surface.
5. Adds the result to the scene with `scene.add_mesh(...)`, and optionally
   exports it to a plain `.obj` file.

This is the mirror image of a splat-transform *generator* script like
`gen-room.mjs` (which emits splats to represent a mesh-like shape) — here
we go the other direction, from an existing splat cloud to an explicit
polygon mesh.

## Install

Copy this folder to:

```
~/.lichtfeld/plugins/splat_to_mesh/
```

or install directly from a Git repo once you push this to GitHub:

```python
import lichtfeld as lf
lf.plugins.install("your-org/splat_to_mesh")
```

Dependencies (`numpy`, `scipy`, `scikit-image`) are declared in
`pyproject.toml` and are installed automatically by LichtFeld on first
load.

## Use

1. Open a scene with a trained/loaded Gaussian splat.
2. Select the splat node in the scene tree (or switch **Source** to
   *Combined Scene* to merge everything).
3. Open the **Splat → Mesh** tab.
4. Tune parameters (see below) and click **Generate Mesh**. A new mesh
   node appears in the scene.
5. Optionally set an output path and click **Export Last Mesh (OBJ)**.

## Parameters

| Parameter | Effect |
|---|---|
| `resolution` | Voxel grid resolution along the longest bounding-box axis. Higher = more detail, slower, more memory. Start around 96–160. |
| `iso_level` | Density threshold defining the surface. Raise to shrink-wrap tighter to dense regions; lower to fill more / bridge gaps. |
| `opacity_threshold` | Drops near-transparent gaussians before reconstruction. |
| `k_neighbors` | How many nearby splats each voxel samples. Higher = smoother but slower. |
| `isotropic` | Uses each splat's average radius (fast). Left as a hook for a future true anisotropic (per-axis covariance) mode. |
| `max_points` | Randomly subsamples very large splat clouds so the KD-tree stays fast. |

## Performance notes

- Cost scales roughly as `O(resolution^3 * k_neighbors)` for the KD-tree
  query. A `resolution=128` grid is ~2.1M voxels; with `k=12` that's
  ~25M neighbor lookups, typically a few seconds on CPU for scenes with
  a few hundred thousand splats.
- If reconstruction is slow or runs out of memory, lower `resolution` or
  `max_points` first.
- `iso_level` almost always needs re-tuning per scene — start around
  `0.3`–`0.5` and adjust based on whether the mesh looks too "puffy"
  (lower it) or has holes (raise the opacity filter's floor, or lower
  the iso level).

## Files

```
splat_to_mesh/
├── pyproject.toml
├── __init__.py
├── props.py                # MeshSettings PropertyGroup — all editable panel state
├── operators/
│   ├── generate_mesh.py   # reconstruction operator (reads MeshSettings)
│   └── export_mesh.py     # OBJ export operator (reads MeshSettings)
├── panels/
│   └── mesh_panel.py      # UI panel, widgets bound to MeshSettings
└── utils/
    └── reconstruction.py  # framework-free numpy/scipy/skimage core
```

`utils/reconstruction.py` has no LichtFeld imports, so you can unit test
`build_density_grid` / `extract_mesh` / `write_obj` standalone with
synthetic point clouds.

## Note on why settings live on a PropertyGroup, not the Operators

The first version of this plugin put `IntProperty`/`FloatProperty` etc.
directly on the `Operator` subclasses and bound panel widgets to those
operator instances. The panel rendered correctly but sliders and
checkboxes didn't respond to input — operator properties appear to be
meant for passing arguments through an actual operator invocation, not
for arbitrary live widget binding. Settings now live on a plain
`MeshSettings(PropertyGroup)` singleton (the same pattern the docs show
working for panel settings), and the operators just read
`MeshSettings.get_instance()` at execute time.

