"""
Core surface-reconstruction logic for the splat_to_mesh plugin.

Pipeline:
  1. build_density_grid  - voxelize an opacity-weighted density field
                            around a Gaussian splat point cloud.
  2. extract_mesh         - run marching cubes on that field to get a
                            world-space triangle mesh.

Kept dependency-light (numpy + scipy + scikit-image) and framework-free so
it can be unit tested outside LichtFeld Studio.
"""
from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree
from scipy import ndimage as ndi

try:
    from skimage.measure import marching_cubes
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "scikit-image is required for mesh reconstruction. It is listed in "
        "this plugin's pyproject.toml dependencies and should install "
        "automatically on first load."
    ) from e


_MAX_VOXELS = 20_000_000  # safety cap so a tiny cube_size can't blow up memory


def build_density_grid(
    means: np.ndarray,
    opacities: np.ndarray,
    scales: np.ndarray,
    resolution: int | None = None,
    voxel_size: float | None = None,
    padding_sigma: float = 3.0,
    k_neighbors: int = 12,
    isotropic: bool = True,
):
    """
    Voxelize the splat cloud into a scalar density field.

    Parameters
    ----------
    means      : (N, 3) float32 world-space splat centers
    opacities  : (N,)   float32 in [0, 1]
    scales     : (N, 3) float32 world-space gaussian radii (already exp'd,
                 i.e. from `SplatData.get_scaling()`, not `scaling_raw`)
    resolution : voxel count along the longest bounding-box axis. Mutually
                 exclusive with voxel_size — pass exactly one.
    voxel_size : explicit world-space edge length per voxel (e.g. a fixed
                 "cube size" for a blocky/Minecraft-style mesh). Mutually
                 exclusive with resolution.
    padding_sigma : padding around the bounding box, in units of the
                 median splat radius, so the surface can close instead of
                 getting clipped at the box edge
    k_neighbors : how many nearby splats contribute density to each voxel.
                 Higher = smoother but slower.
    isotropic  : if True, use each splat's mean radius (fast, round
                 falloff). If False, reserved for a future anisotropic
                 (per-axis) falloff.

    Returns
    -------
    (grid, origin, voxel_size)
      grid       : (rx, ry, rz) float32 density volume
      origin     : (3,) float32 world position of voxel (0,0,0)'s corner
      voxel_size : float, world units per voxel
    """
    if len(means) == 0:
        raise ValueError("No splats to voxelize")
    if (resolution is None) == (voxel_size is None):
        raise ValueError("Pass exactly one of resolution or voxel_size")

    mean_radius = scales.mean(axis=1)
    pad = float(np.median(mean_radius) * padding_sigma)

    bb_min = means.min(axis=0) - pad
    bb_max = means.max(axis=0) + pad
    extent = bb_max - bb_min
    extent = np.maximum(extent, 1e-6)

    if voxel_size is None:
        voxel_size = float(extent.max() / max(resolution, 2))
    else:
        voxel_size = float(voxel_size)
        if voxel_size <= 0:
            raise ValueError("cube_size must be > 0")

    dims = np.maximum(np.ceil(extent / voxel_size).astype(int), 2)

    total_voxels = int(dims[0]) * int(dims[1]) * int(dims[2])
    if total_voxels > _MAX_VOXELS:
        raise ValueError(
            f"Cube size {voxel_size:.4g} would require {total_voxels:,} voxels "
            f"(limit {_MAX_VOXELS:,}) — increase Cube Size or shrink the bounding box."
        )

    xs = bb_min[0] + (np.arange(dims[0]) + 0.5) * voxel_size
    ys = bb_min[1] + (np.arange(dims[1]) + 0.5) * voxel_size
    zs = bb_min[2] + (np.arange(dims[2]) + 0.5) * voxel_size
    gx, gy, gz = np.meshgrid(xs, ys, zs, indexing="ij")
    voxel_centers = np.stack([gx.ravel(), gy.ravel(), gz.ravel()], axis=1)

    tree = cKDTree(means)
    k = min(k_neighbors, len(means))
    dists, idx = tree.query(voxel_centers, k=k, workers=-1)
    if k == 1:
        dists = dists[:, None]
        idx = idx[:, None]

    neighbor_radius = mean_radius[idx]          # (V, k)
    neighbor_opacity = opacities[idx]            # (V, k)
    sigma = np.maximum(neighbor_radius, 1e-6)
    weight = neighbor_opacity * np.exp(-0.5 * (dists / sigma) ** 2)
    density = weight.sum(axis=1)

    grid = density.reshape(dims).astype(np.float32)
    return grid, bb_min.astype(np.float32), voxel_size


def extract_mesh(grid: np.ndarray, origin: np.ndarray, voxel_size: float, iso_level: float):
    """
    Run marching cubes on a density grid and return a world-space mesh.

    Returns (vertices, faces, normals) as float32/int32/float32 numpy arrays.
    """
    grid_max = float(grid.max())
    if grid_max <= iso_level:
        raise ValueError(
            f"iso_level {iso_level:.4f} is at or above the max density "
            f"{grid_max:.4f} in the grid — nothing to extract. Lower the "
            f"threshold, raise resolution, or lower the opacity filter."
        )

    verts, faces, normals, _values = marching_cubes(grid, level=iso_level)
    verts_world = origin + verts * voxel_size
    return (
        verts_world.astype(np.float32),
        faces.astype(np.int32),
        normals.astype(np.float32),
    )


# Six cube faces as (outward normal, 4 corners in voxel-local unit-cube
# space), each wound counter-clockwise as seen from outside the cube so
# the cross product of the first two edges matches the outward normal.
_CUBE_FACES = [
    ((1, 0, 0),  [(1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1)]),   # +X
    ((-1, 0, 0), [(0, 0, 1), (0, 1, 1), (0, 1, 0), (0, 0, 0)]),   # -X
    ((0, 1, 0),  [(0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0)]),   # +Y
    ((0, -1, 0), [(0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)]),   # -Y
    ((0, 0, 1),  [(0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)]),   # +Z
    ((0, 0, -1), [(0, 1, 0), (1, 1, 0), (1, 0, 0), (0, 0, 0)]),   # -Z
]

# Classic Minecraft-style fake directional lighting: top brightest, bottom
# darkest, the two horizontal axes shaded in between (and slightly apart
# from each other) so blocky geometry reads with depth under flat/ambient
# lighting instead of looking uniformly gray.
_FACE_SHADE = {
    (0, 1, 0):  1.00,  # top
    (0, -1, 0): 0.50,  # bottom
    (0, 0, 1):  0.80,  # north/south
    (0, 0, -1): 0.80,
    (1, 0, 0):  0.60,  # east/west
    (-1, 0, 0): 0.60,
}


def build_voxel_mesh(grid: np.ndarray, origin: np.ndarray, voxel_size: float,
                      iso_level: float, gap_fill: int = 0,
                      base_color: tuple = (1.0, 1.0, 1.0)):
    """
    Build a blocky "Minecraft" style mesh: emit one cube per voxel whose
    density exceeds iso_level. Faces shared between two solid voxels are
    culled so only the exterior surface is emitted (keeps triangle count
    proportional to surface area, not volume).

    gap_fill : morphological-closing strength (0 = off). Closes small holes
        in sparse/thin regions (e.g. floors where splat coverage is thin)
        by dilating then eroding the occupancy mask. Uses full 26-neighbor
        connectivity so it can bridge gaps within a single-voxel-thick
        sheet, where 6-connectivity closing has no vertical neighbors to
        work with and does nothing. The mask is zero-padded before closing
        and cropped back afterward so the true bounding-box edges aren't
        misread as an artificial wraparound boundary and eroded away.

    base_color : (r, g, b) in [0, 1], the flat color of every cube before
        per-face shading (see _FACE_SHADE) darkens/brightens it by
        direction to fake depth, Minecraft-style.

    Returns (vertices, faces, normals, colors) as float32/int32/float32/float32
    numpy arrays. `colors` is per-vertex RGB, same length as `vertices`.
    """
    occupied = grid > iso_level

    if gap_fill > 0:
        pad = gap_fill + 1
        structure = ndi.generate_binary_structure(3, 3)
        padded = np.pad(occupied, pad, mode="constant", constant_values=False)
        closed = ndi.binary_closing(padded, structure=structure, iterations=gap_fill)
        occupied = closed[pad:-pad, pad:-pad, pad:-pad]

    if not occupied.any():
        grid_max = float(grid.max())
        raise ValueError(
            f"iso_level {iso_level:.4f} is at or above the max density "
            f"{grid_max:.4f} in the grid — nothing to extract. Lower the "
            f"threshold, raise resolution, or lower the opacity filter."
        )

    dims = grid.shape
    ix, iy, iz = np.nonzero(occupied)

    verts_list = []
    normals_list = []
    colors_list = []
    faces_list = []
    vcount = 0
    base_rgb = np.clip(np.array(base_color, dtype=np.float32), 0.0, 1.0)

    for (dx, dy, dz), corners in _CUBE_FACES:
        nx, ny, nz = ix + dx, iy + dy, iz + dz
        in_bounds = ((nx >= 0) & (nx < dims[0]) &
                     (ny >= 0) & (ny < dims[1]) &
                     (nz >= 0) & (nz < dims[2]))
        exposed = ~in_bounds
        exposed[in_bounds] |= ~occupied[nx[in_bounds], ny[in_bounds], nz[in_bounds]]

        if not exposed.any():
            continue

        sel_x, sel_y, sel_z = ix[exposed], iy[exposed], iz[exposed]
        n = len(sel_x)

        corner_blocks = []
        for (cx, cy, cz) in corners:
            corner_blocks.append(np.stack(
                [sel_x + cx, sel_y + cy, sel_z + cz], axis=1))
        verts_list.extend(corner_blocks)

        normal = np.array([dx, dy, dz], dtype=np.float32)
        normals_list.extend([np.tile(normal, (n, 1))] * 4)

        face_color = base_rgb * _FACE_SHADE[(dx, dy, dz)]
        colors_list.extend([np.tile(face_color, (n, 1))] * 4)

        base = vcount
        idx4 = np.arange(n)
        f0 = base + idx4
        f1 = base + n + idx4
        f2 = base + 2 * n + idx4
        f3 = base + 3 * n + idx4
        faces_list.append(np.stack([f0, f1, f2], axis=1))
        faces_list.append(np.stack([f0, f2, f3], axis=1))
        vcount += 4 * n

    if not verts_list:
        raise ValueError("No exposed faces found — every occupied voxel is fully enclosed.")

    verts = np.concatenate(verts_list, axis=0).astype(np.float64)
    normals = np.concatenate(normals_list, axis=0)
    colors = np.concatenate(colors_list, axis=0)
    faces = np.concatenate(faces_list, axis=0)

    verts_world = origin + verts * voxel_size
    return (
        verts_world.astype(np.float32),
        faces.astype(np.int32),
        normals.astype(np.float32),
        colors.astype(np.float32),
    )


def write_obj(path: str, vertices: np.ndarray, faces: np.ndarray, colors: np.ndarray = None) -> None:
    """Minimal dependency-free OBJ writer (positions + triangle faces, with
    an optional per-vertex color extension: `v x y z r g b`). This isn't
    part of the official OBJ spec but is widely read by tools such as
    MeshLab and CloudCompare."""
    with open(path, "w") as f:
        if colors is None:
            for v in vertices:
                f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
        else:
            for v, c in zip(vertices, colors):
                f.write(f"v {v[0]:.6f} {v[1]:.6f} {v[2]:.6f} {c[0]:.4f} {c[1]:.4f} {c[2]:.4f}\n")
        for tri in faces:
            # OBJ face indices are 1-based
            f.write(f"f {tri[0] + 1} {tri[1] + 1} {tri[2] + 1}\n")
