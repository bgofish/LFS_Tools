import numpy as np

import lichtfeld as lf
from lfs_plugins.types import Operator

from ..props import MeshSettings
from ..utils.reconstruction import build_density_grid, extract_mesh, build_voxel_mesh

# Cache of the last generated mesh (world-space numpy arrays), so the
# export operator can write it to disk without re-running reconstruction.
_last_mesh = {"vertices": None, "faces": None, "colors": None}


class GenerateMeshFromSplats(Operator):
    label = "Generate Mesh From Splat"
    description = "Reconstruct a polygon mesh around the active Gaussian splat"
    options = {"UNDO"}

    @classmethod
    def poll(cls, context) -> bool:
        return lf.has_scene()

    def execute(self, context) -> dict:
        settings = MeshSettings.get_instance()

        scene = lf.get_scene()
        if scene is None:
            lf.log.warn("No scene loaded")
            return {"status": "CANCELLED"}

        splat_data = self._get_source_splat_data(scene, settings)
        if splat_data is None or splat_data.num_points == 0:
            lf.log.warn("No splat data found. Select a splat node, or switch Source to 'Combined Scene'.")
            return {"status": "CANCELLED"}

        means = splat_data.get_means().cpu().numpy()
        opacity = splat_data.get_opacity().cpu().numpy().reshape(-1)
        scaling = splat_data.get_scaling().cpu().numpy()

        keep = opacity >= settings.opacity_threshold
        means, opacity, scaling = means[keep], opacity[keep], scaling[keep]

        if len(means) == 0:
            lf.log.warn("No gaussians left after opacity filtering — lower Min Splat Opacity.")
            return {"status": "CANCELLED"}

        if len(means) > settings.max_points:
            rng = np.random.default_rng(0)
            idx = rng.choice(len(means), settings.max_points, replace=False)
            means, opacity, scaling = means[idx], opacity[idx], scaling[idx]
            lf.log.info(f"Subsampled to {settings.max_points:,} splats for reconstruction")

        blocky = settings.style == "blocky"
        colors = None
        try:
            if blocky:
                lf.log.info(f"Voxelizing {len(means):,} splats at cube size {settings.cube_size}...")
                grid, origin, voxel_size = build_density_grid(
                    means, opacity, scaling,
                    voxel_size=settings.cube_size,
                    k_neighbors=settings.k_neighbors,
                    isotropic=settings.isotropic,
                )
                verts, faces, normals, colors = build_voxel_mesh(
                    grid, origin, voxel_size, settings.iso_level,
                    gap_fill=settings.gap_fill,
                    base_color=tuple(settings.cube_color),
                )
            else:
                lf.log.info(f"Voxelizing {len(means):,} splats at resolution {settings.resolution}...")
                grid, origin, voxel_size = build_density_grid(
                    means, opacity, scaling,
                    resolution=settings.resolution,
                    k_neighbors=settings.k_neighbors,
                    isotropic=settings.isotropic,
                )
                verts, faces, normals = extract_mesh(grid, origin, voxel_size, settings.iso_level)
        except ValueError as e:
            lf.log.error(str(e))
            return {"status": "CANCELLED"}

        lf.log.info(f"Extracted mesh: {len(verts):,} verts, {len(faces):,} faces")

        v_tensor = lf.Tensor.from_numpy(verts)
        f_tensor = lf.Tensor.from_numpy(faces)
        n_tensor = lf.Tensor.from_numpy(normals)
        c_tensor = lf.Tensor.from_numpy(colors) if colors is not None else None

        mesh_id = scene.add_mesh(
            settings.mesh_name or "SplatMesh",
            vertices=v_tensor,
            indices=f_tensor,
            colors=c_tensor,
            normals=n_tensor,
        )
        scene.notify_changed()

        _last_mesh["vertices"] = verts
        _last_mesh["faces"] = faces
        _last_mesh["colors"] = colors

        lf.log.info(f"Added mesh node id={mesh_id}")
        return {
            "status": "FINISHED",
            "node_id": mesh_id,
            "vertex_count": len(verts),
            "face_count": len(faces),
        }

    def _get_source_splat_data(self, scene, settings):
        if settings.source == "combined":
            return scene.combined_model()

        names = lf.get_selected_node_names()
        if not names:
            return None
        node = scene.get_node(names[0])
        if node is None:
            return None
        return node.splat_data()
