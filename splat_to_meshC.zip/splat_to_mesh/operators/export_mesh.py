import lichtfeld as lf
from lfs_plugins.types import Operator

from ..props import MeshSettings
from ..utils.reconstruction import write_obj
from . import generate_mesh as _gen_mesh_module


class ExportLastSplatMesh(Operator):
    label = "Export Last Mesh (OBJ)"
    description = "Write the most recently generated splat mesh to an .obj file"
    options = set()

    @classmethod
    def poll(cls, context) -> bool:
        return _gen_mesh_module._last_mesh["vertices"] is not None

    def execute(self, context) -> dict:
        settings = MeshSettings.get_instance()

        verts = _gen_mesh_module._last_mesh["vertices"]
        faces = _gen_mesh_module._last_mesh["faces"]
        colors = _gen_mesh_module._last_mesh.get("colors")
        if verts is None or faces is None:
            lf.log.warn("No mesh has been generated yet — run Generate Mesh From Splat first.")
            return {"status": "CANCELLED"}

        if not settings.output_path:
            lf.log.warn("Set an output path first.")
            return {"status": "CANCELLED"}

        write_obj(settings.output_path, verts, faces, colors)
        lf.log.info(f"Wrote {len(verts):,} verts / {len(faces):,} faces to {settings.output_path}")
        return {"status": "FINISHED", "path": settings.output_path}
