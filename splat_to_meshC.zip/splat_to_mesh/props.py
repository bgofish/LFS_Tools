"""
Editable settings for the splat_to_mesh plugin.

These live on a plain PropertyGroup (not an Operator) because the docs'
only confirmed-working example of live UI-editable panel state binds
widgets to a PropertyGroup singleton (`MaterialSettings.get_instance()`).
Operator properties are documented for passing arguments when an
operator is invoked, not necessarily for arbitrary widget binding
outside that invocation — binding sliders directly to an Operator
subclass's properties is what produced read-only-looking widgets.
"""
from lfs_plugins.props import (
    PropertyGroup, FloatProperty, IntProperty, BoolProperty,
    StringProperty, EnumProperty, FloatVectorProperty,
)


class MeshSettings(PropertyGroup):
    source: str = EnumProperty(
        items=[
            ("selected", "Selected Node", "Use the first selected splat node"),
            ("combined", "Combined Scene", "Merge all splat nodes in the scene"),
        ],
        default="selected",
        name="Source",
    )
    mesh_name: str = StringProperty(
        default="SplatMesh",
        name="Mesh Node Name",
        description="Name for the new mesh node added to the scene",
    )
    style: str = EnumProperty(
        items=[
            ("smooth", "Smooth", "Marching-cubes surface"),
            ("blocky", "Blocky (Minecraft)", "One cube per occupied voxel, exposed faces only"),
        ],
        default="blocky",
        name="Style",
    )
    resolution: int = IntProperty(
        default=128, min=16, max=384, step=16,
        name="Grid Resolution",
        description="Voxel count along the longest bounding-box axis. Higher is slower and more detailed. Used in Smooth style only.",
    )
    cube_size: float = FloatProperty(
        default=1.0, min=0.001, max=5.0, step=0.01, precision=4,
        name="Cube Size",
        description="World-space edge length of each cube. Used in Blocky style only.",
    )
    gap_fill: int = IntProperty(
        default=0, min=0, max=5, step=1,
        name="Fill Gaps",
        description="Morphological closing strength applied to the cube occupancy mask before meshing. Closes small holes in sparse/thin regions like floors. 0 = off. Blocky style only.",
    )
    cube_color: tuple = FloatVectorProperty(
        default=(0.65, 0.65, 0.65), size=3, min=0.0, max=1.0, subtype="COLOR",
        name="Cube Color",
        description="Base color for each cube before Minecraft-style per-face shading (top brightest, bottom darkest, sides in between). Used in Blocky style only.",
    )
    iso_level: float = FloatProperty(
        default=0.35, min=0.01, max=5.0, step=0.05, precision=3,
        name="Iso Level",
        description="Density threshold that defines the surface. Raise it to shrink-wrap tighter, lower it to fill more.",
    )
    opacity_threshold: float = FloatProperty(
        default=0.05, min=0.0, max=1.0, step=0.01, subtype="FACTOR",
        name="Min Splat Opacity",
        description="Ignore gaussians below this opacity before reconstruction (filters fog/noise splats).",
    )
    k_neighbors: int = IntProperty(
        default=12, min=1, max=64, step=1,
        name="Neighbor Count",
        description="How many nearby splats contribute to each voxel's density. Higher is smoother and slower.",
    )
    isotropic: bool = BoolProperty(
        default=True,
        name="Isotropic Falloff",
        description="Use each splat's average radius instead of full anisotropic covariance (faster).",
    )
    max_points: int = IntProperty(
        default=2_000_000, min=10_000, max=20_000_000, step=100_000,
        name="Max Splats",
        description="Randomly subsample the splat cloud above this count before reconstruction, to keep the KD-tree fast.",
    )
    output_path: str = StringProperty(
        default="c:\TEMP\splat_mesh.obj",
        subtype="FILE_PATH",
        name="Output Path",
        description="Where to save the exported .obj file",
    )
