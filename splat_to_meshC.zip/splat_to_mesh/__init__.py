import lichtfeld as lf

from .operators.generate_mesh import GenerateMeshFromSplats
from .operators.export_mesh import ExportLastSplatMesh
from .panels.mesh_panel import SplatMeshPanel

# MeshSettings (a plain PropertyGroup) is NOT registered here —
# register_class only accepts Panel/Operator/Menu subclasses. It doesn't
# need registration anyway: PropertyGroup.get_instance() lazily creates
# the singleton on first access, which panels/mesh_panel.py already does.
_classes = [GenerateMeshFromSplats, ExportLastSplatMesh, SplatMeshPanel]


def on_load():
    for cls in _classes:
        lf.register_class(cls)
    lf.log.info("splat_to_mesh loaded")


def on_unload():
    for cls in reversed(_classes):
        lf.unregister_class(cls)
    lf.log.info("splat_to_mesh unloaded")
