from pathlib import Path

import lichtfeld as lf

from ..props import MeshSettings
from ..operators.generate_mesh import GenerateMeshFromSplats
from ..operators.export_mesh import ExportLastSplatMesh


class SplatMeshPanel(lf.ui.Panel):
    id = "splat_to_mesh.main_panel"
    label = "Splat \u2192 Mesh"
    space = lf.ui.PanelSpace.MAIN_PANEL_TAB
    order = 250
    poll_dependencies = {
        lf.ui.PollDependency.SCENE,
        lf.ui.PollDependency.SELECTION,
    }
    template     = str(Path(__file__).resolve().with_name("mesh_panel.rml"))
    height_mode  = lf.ui.PanelHeightMode.CONTENT

    def __init__(self):
        self._settings = MeshSettings.get_instance()
        self._gen       = GenerateMeshFromSplats()
        self._export    = ExportLastSplatMesh()
        self._handle    = None
        self._status    = ""

    @classmethod
    def poll(cls, context) -> bool:
        return True

    # ── Lifecycle ────────────────────────────────────────────────────────────

    def on_bind_model(self, ctx):
        model = ctx.create_data_model("splat_to_mesh_panel")
        s = self._settings

        # --- Source (two-button toggle) ---
        model.bind_func("source_btn_selected",
                         lambda: "[Selected Node]" if s.source == "selected" else "Selected Node")
        model.bind_func("source_btn_combined",
                         lambda: "[Combined Scene]" if s.source == "combined" else "Combined Scene")
        model.bind_event("source_selected", self._on_source_selected)
        model.bind_event("source_combined", self._on_source_combined)

        # --- Mesh node name ---
        model.bind("mesh_name",
                   lambda: s.mesh_name,
                   lambda v: setattr(s, "mesh_name", str(v)))

        # --- Style (two-button toggle) ---
        model.bind_func("style_btn_smooth",
                         lambda: "[Smooth]" if s.style == "smooth" else "Smooth")
        model.bind_func("style_btn_blocky",
                         lambda: "[Blocky (Minecraft)]" if s.style == "blocky" else "Blocky (Minecraft)")
        model.bind_func("is_smooth", lambda: s.style == "smooth")
        model.bind_func("is_blocky", lambda: s.style == "blocky")
        model.bind_event("style_smooth", self._on_style_smooth)
        model.bind_event("style_blocky", self._on_style_blocky)

        # --- Grid resolution (Smooth style) ---
        model.bind_func("res_min", lambda: "16")
        model.bind_func("res_max", lambda: "384")
        model.bind_func("res_step", lambda: "16")
        model.bind_func("tip_resolution",
                         lambda: "Voxel count along the longest bounding-box axis. Higher is slower and more detailed.")
        model.bind("resolution_str",
                   lambda: str(s.resolution),
                   lambda v: self._set_int_prop("resolution", "resolution_str", v, 16, 384))

        # --- Cube size (Blocky style) ---
        model.bind_func("cube_size_min", lambda: "0.001")
        model.bind_func("cube_size_max", lambda: "5.0")
        model.bind_func("cube_size_step", lambda: "0.01")
        model.bind_func("tip_cube_size",
                         lambda: "World-space edge length of each cube. Smaller = more detail but slower and more triangles.")
        model.bind("cube_size_str",
                   lambda: f"{s.cube_size:.4f}",
                   lambda v: self._set_float_prop("cube_size", "cube_size_str", v, 0.001, 5.0))

        # --- Fill gaps (Blocky style) ---
        model.bind_func("gap_fill_min", lambda: "0")
        model.bind_func("gap_fill_max", lambda: "5")
        model.bind_func("gap_fill_step", lambda: "1")
        model.bind_func("tip_gap_fill",
                         lambda: "Morphological closing strength applied to the cube mask before meshing. Closes small holes in sparse/thin regions like floors. 0 = off.")
        model.bind("gap_fill_str",
                   lambda: str(s.gap_fill),
                   lambda v: self._set_int_prop("gap_fill", "gap_fill_str", v, 0, 5))

        # --- Cube color (Blocky style) ---
        model.bind_func("color_min", lambda: "0.0")
        model.bind_func("color_max", lambda: "1.0")
        model.bind_func("color_step", lambda: "0.01")
        model.bind_func("tip_cube_color",
                         lambda: "Base cube color before per-face Minecraft-style shading.")
        model.bind("cube_r_str",
                   lambda: f"{s.cube_color[0]:.3f}",
                   lambda v: self._set_color_channel(0, "cube_r_str", v))
        model.bind("cube_g_str",
                   lambda: f"{s.cube_color[1]:.3f}",
                   lambda v: self._set_color_channel(1, "cube_g_str", v))
        model.bind("cube_b_str",
                   lambda: f"{s.cube_color[2]:.3f}",
                   lambda v: self._set_color_channel(2, "cube_b_str", v))

        # --- Iso level ---
        model.bind_func("iso_min", lambda: "0.01")
        model.bind_func("iso_max", lambda: "5.0")
        model.bind_func("iso_step", lambda: "0.05")
        model.bind_func("tip_iso",
                         lambda: "Density threshold that defines the surface. Raise it to shrink-wrap tighter, lower it to fill more.")
        model.bind("iso_str",
                   lambda: f"{s.iso_level:.3f}",
                   lambda v: self._set_float_prop("iso_level", "iso_str", v, 0.01, 5.0))

        # --- Min splat opacity ---
        model.bind_func("opacity_min", lambda: "0.0")
        model.bind_func("opacity_max", lambda: "1.0")
        model.bind_func("opacity_step", lambda: "0.01")
        model.bind_func("tip_opacity",
                         lambda: "Ignore gaussians below this opacity before reconstruction (filters fog/noise splats).")
        model.bind("opacity_str",
                   lambda: f"{s.opacity_threshold:.3f}",
                   lambda v: self._set_float_prop("opacity_threshold", "opacity_str", v, 0.0, 1.0))

        # --- Neighbor count ---
        model.bind_func("k_min", lambda: "1")
        model.bind_func("k_max", lambda: "64")
        model.bind_func("k_step", lambda: "1")
        model.bind_func("tip_k",
                         lambda: "How many nearby splats contribute to each voxel's density. Higher is smoother and slower.")
        model.bind("k_str",
                   lambda: str(s.k_neighbors),
                   lambda v: self._set_int_prop("k_neighbors", "k_str", v, 1, 64))

        # --- Isotropic falloff ---
        model.bind_func("tip_isotropic",
                         lambda: "Use each splat's average radius instead of full anisotropic covariance (faster).")
        model.bind("isotropic",
                   lambda: s.isotropic,
                   self._set_isotropic)

        # --- Max splats ---
        model.bind_func("max_points_min", lambda: "10000")
        model.bind_func("max_points_max", lambda: "20000000")
        model.bind_func("max_points_step", lambda: "100000")
        model.bind_func("tip_max_points",
                         lambda: "Randomly subsample the splat cloud above this count before reconstruction, to keep the KD-tree fast.")
        model.bind("max_points_str",
                   lambda: str(s.max_points),
                   lambda v: self._set_int_prop("max_points", "max_points_str", v, 10_000, 20_000_000))

        # --- Output path ---
        model.bind("output_path",
                   lambda: s.output_path,
                   lambda v: setattr(s, "output_path", str(v)))

        # --- Actions ---
        model.bind_event("do_generate", self._on_generate)
        model.bind_event("do_export", self._on_export)

        # --- Status ---
        model.bind_func("status_text", lambda: self._status)
        model.bind_func("status_class", self._status_class)

        self._handle = model.get_handle()

    def on_unmount(self, doc):
        doc.remove_data_model("splat_to_mesh_panel")
        self._handle = None

    # ── Event handlers ──────────────────────────────────────────────────────

    def _on_source_selected(self, handle, event, args):
        self._settings.source = "selected"
        self._dirty("source_btn_selected", "source_btn_combined")

    def _on_source_combined(self, handle, event, args):
        self._settings.source = "combined"
        self._dirty("source_btn_selected", "source_btn_combined")

    def _on_style_smooth(self, handle, event, args):
        self._settings.style = "smooth"
        self._dirty("style_btn_smooth", "style_btn_blocky", "is_smooth", "is_blocky")

    def _on_style_blocky(self, handle, event, args):
        self._settings.style = "blocky"
        self._dirty("style_btn_smooth", "style_btn_blocky", "is_smooth", "is_blocky")

    def _on_generate(self, handle, event, args):
        if not GenerateMeshFromSplats.poll(None):
            self._status = "Generate Mesh: no scene loaded."
            lf.log.warn(self._status)
        else:
            result = self._gen.execute(None)
            lf.log.info(f"Generate result: {result}")
            if result.get("status") == "FINISHED":
                self._status = (f"Generated mesh: {result.get('vertex_count', 0):,} verts, "
                                f"{result.get('face_count', 0):,} faces.")
            else:
                self._status = "Generate cancelled \u2014 see log for details."
        self._dirty("status_text", "status_class")

    def _on_export(self, handle, event, args):
        if not ExportLastSplatMesh.poll(None):
            self._status = "Export: generate a mesh first."
            lf.log.warn(self._status)
        else:
            result = self._export.execute(None)
            lf.log.info(f"Export result: {result}")
            if result.get("status") == "FINISHED":
                self._status = f"Exported mesh to {result.get('path', '')}."
            else:
                self._status = "Export cancelled \u2014 see log for details."
        self._dirty("status_text", "status_class")

    # ── Setters ──────────────────────────────────────────────────────────────

    def _set_int_prop(self, prop_name, field_name, value, lo, hi):
        try:
            v = int(round(float(value)))
        except (TypeError, ValueError):
            return
        setattr(self._settings, prop_name, max(lo, min(hi, v)))
        self._dirty(field_name)

    def _set_float_prop(self, prop_name, field_name, value, lo, hi):
        try:
            v = float(value)
        except (TypeError, ValueError):
            return
        setattr(self._settings, prop_name, max(lo, min(hi, v)))
        self._dirty(field_name)

    def _set_isotropic(self, value):
        if isinstance(value, str):
            self._settings.isotropic = value.lower() not in ("false", "0", "")
        else:
            self._settings.isotropic = bool(value)

    def _set_color_channel(self, channel, field_name, value):
        try:
            v = max(0.0, min(1.0, float(value)))
        except (TypeError, ValueError):
            return
        rgb = list(self._settings.cube_color)
        rgb[channel] = v
        self._settings.cube_color = tuple(rgb)
        self._dirty(field_name)

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _dirty(self, *fields):
        if not self._handle:
            return
        for f in fields:
            self._handle.dirty(f)

    def _status_class(self) -> str:
        s = self._status
        if s.startswith(("Generated", "Exported")):
            return "text-accent"
        if s and (s.startswith(("Generate cancelled", "Export cancelled"))
                  or "no scene" in s.lower() or "generate a mesh first" in s.lower()):
            return "text-muted"
        return "text-default"
